from requests.packages.urllib3.exceptions import InsecureRequestWarning,InsecurePlatformWarning
import re
import requests
from pprint import pprint

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
requests.packages.urllib3.disable_warnings(InsecurePlatformWarning)
url = 'https://kyfw.12306.cn/otn/resources/js/framework/station_name.js?station_version=1.9063'
response = requests.get(url, verify=False)
result = dict(re.findall(u'([\u4e00-\u9fa5]+)\|([A-Z]+)', response.text))
print(result.keys())
print(result.values())

