from setuptools import setup

setup(
    name = 'vsearch',
    version = '1.0',
    description = 'The Head First Python Search Tools',
    author = 'Dong',
    py_modules = ['vsearch'],
)
